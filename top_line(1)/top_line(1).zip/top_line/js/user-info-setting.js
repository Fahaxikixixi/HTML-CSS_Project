// 渲染初始化页面
getUserInfo()
// 渲染初始化页面
function getUserInfo() {
  ajax({ url: '/account/profile/put' }, function (res) {
    let { result } = res
    console.log(result);
    // 头像
    $('.upload-tx-btn img').eq(0).attr('src', result.headImageUrl)
    // 主图
    let mainImg = ''
    result.mainImages.forEach(item => {
      mainImg += `
      <a href="javascript:;">
        <img src="${item}" width="100%" alt="">
      </a>
      `
    });
    mainImg += `
    <label for="upload" class="upload-img-btn">
      <input type="file" id="upload" hidden>
    </label>
    `
    $('.main-img-wrap').html(mainImg)
    // 生日
    $('.birth').text(result.birth)
    // 昵称
    $('.nick-name').val(result.nickname)
    // 婚否
    $('.marital-status').text(result.maritalStatus)
    // 性别
    $('.sex').text(result.sex)
    // 身高
    $('.stature').text(result.stature)
    // 户籍
    $('.census').text(result.census)
    // 职业
    $('.profession').text(result.profession)
    // 学历
    $('.education').text(result.education)
    // 单位名称
    $('.shop-name').text(result.shopName)
    // 主营
    $('.primary-service').text(result.primaryService)
    // 所属区域
    $('.area-name').text(result.areaName)
    // 收货地址
    $('.address').text(result.address)
    // 位置
    $('.location').text(result.location)
  })
}

// 更改头像
$('#upload-tx').on('change', function () {
  // let formData = new FormData()
  let windowURL = window.URL || window.webkitURL;
  let txURL = windowURL.createObjectURL(this.files[0])
  console.log(txURL);
  $('.upload-tx-btn img').eq(0).attr('src', txURL)
  // formData.append('attache', this.files[i])
})

// 更改主图
$('.main-img-wrap').on('change', '#upload', function () {
  let formData = new FormData()
  let mainImgHTML = ''
  // 计算上传后图片总数
  let num = $('.main-img-wrap>a').length + this.files.length
  // 限制只能上传9张图片
  if (num > 9) {
    return showTip('最多上传9个文件')
  }
  // 渲染图片预览
  for (let i = 0; i < this.files.length; i++) {
    let windowURL = window.URL || window.webkitURL;
    let imgURL = windowURL.createObjectURL(this.files[i])
    // 判断不是图片
    if (this.files[i].type.split('/')[0] !== 'image') {
      return showTip('只能上传图片！')
    }
    mainImgHTML += `
    <a href="javascript:;">
      <img src="${imgURL}" width="100%" alt="">
    </a>
    `
    // formData.append('attache', this.files[i])
  }
  // uploadToServer(formData)
  $('.main-img-wrap').prepend(mainImgHTML)
})

// 上传附件到服务器
let albumsArr = []
function uploadToServer(data) {
  ajax({
    url: '/posts/attache', method: 'post', data, processData: false,
    contentType: false,
  }, function (res) {
    albumsArr.push({
      'url': res.result.url,
      'coverUrl': res.result.coverUrl,
      'type': res.result.type
    })
  })
}

// 选择生日
$('.birth').on('tap', function () {
  let birthSelect = new MobileSelect({
    trigger: '.birth',
    title: '选择生日',
    wheels: [
      { data: relClassifyData }
    ],
    transitionEnd: function (id, value) {

    },
    callback: function (id, value) {
      console.log(value);
      
    }
  })
})