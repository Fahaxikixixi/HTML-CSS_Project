// 选则分类
$('.show-picker').on('tap', function () {
  let mobileSelect = new MobileSelect({
    trigger: '.show-picker',
    title: '选择分类',
    wheels: [
      { data: relClassifyData }
    ],
    transitionEnd: function (id, value) {
      // 只有选择本地展厅时才出现费用
      if (value[0].id === '3') {
        $('.edit-price').show()
        $('.edit-name').show()
      } else {
        $('.edit-price').hide()
        $('.edit-name').hide()
      }
    },
    callback: function (id, value) {
      // 获取当前频道id (发布时需要)
      let channelId = value[0].id
      // 获取当前分类id（发布时需要)
      let classifyId = (value[1] ? value[1].id : null)
      $('.show-picker').attr('classify-id', classifyId)
      $('.show-picker').attr('channel-id', channelId)
      // 避免重复跳出多次picker
      $('.mobileSelect').remove()

      // 只有选择本地展厅时才出现费用
      if (value[0].id === '3') {
        $('.edit-price').show()
        $('.edit-name').show()
      } else {
        $('.edit-price').hide()
        $('.edit-name').hide()
      }
    }
  })
})

// 显示地址开关
$('.switch-off').on('tap', function () {
  if ($(this).attr('isopen') == 'true') {
    $(this).attr('isopen', 'false')
    $(this).removeClass('istrue')
    $(this).addClass('isfalse')
    return
  }
  if ($(this).attr('isopen') == 'false') {
    $(this).attr('isopen', 'true')
    $(this).removeClass('isfalse')
    $(this).addClass('istrue')
    return
  }
})

// 添加标签
$('form').on('submit', function (e) {
  let text = $('.tag-input').val()
  let tagList = `
  <span>${text}<i class="close-icon"></i></span>
  `
  $('.tag-list').append(tagList)
  return false;
})

// 删除标签
$('.tag-list').on('tap', '.close-icon', function () {
  $(this).parent().remove()
})

// 图片上传
$('#upload').on('change', function () {
  let formData = new FormData()
  let imgListHTML = ''
  // 计算上传后图片总数
  let num = $('.upload-img-wrap>a').length + this.files.length
  // 限制只能上传9张图片
  if (num > 9) {
    return showTip('最多上传9个文件')
  }
  // 渲染图片预览
  for (let i = 0; i < this.files.length; i++) {
    let windowURL = window.URL || window.webkitURL;
    let videoURL = windowURL.createObjectURL(this.files[i])
    // 判断是图片
    if (this.files[i].type.split('/')[0] === 'image') {
      imgListHTML += `
      <a><img src="${videoURL}" alt=""></a>
      `
    }
    // 判断是视频
    if (this.files[i].type.split('/')[0] === 'video') {
      imgListHTML += `
      <a><video src="${videoURL}" poster="${videoURL}" preload="none" alt=""></video></a>
      `
    }
    formData.append('attache', this.files[i])
  }
  uploadToServer(formData)
  $('.upload-img-wrap').append(imgListHTML)
})

// 帖子附件上传到服务器 需传入提交数据
let albumsArr = []
function uploadToServer(data) {
  ajax({
    url: '/posts/attache', method: 'post', data, processData: false,
    contentType: false,
  }, function (res) {
    albumsArr.push({
      'url': res.result.url,
      'coverUrl': res.result.coverUrl,
      'type': res.result.type
    })
  })
}

// 点击发布
$('.save').on('tap', function () {
  // 同意须知
  if ($('#agree').get(0).checked === false) {
    return showTip('请先同意发布须知')
  }
  // 标签集合
  let tagArr = []
  $('.tag-list>span').each((index, item) => {
    tagArr.push($(item).text())
  })
  // 发布时需要用到的参数
  let data = {}
  data.channelId = $('.show-picker').attr('channel-id')
  data.classifyId = $('.show-picker').attr('classify-id')
  data.content = $('.tarea-text').val()
  data.price = $('.price').val()
  data.showAddress = $('.switch-off').attr('isopen') === 'true' ? true : false
  data.tag = tagArr
  data.albums = albumsArr
  data.title = $('.edit-name input').eq(0).val()
  data.unit = $('.unit').val()
  release(data)
})

// 发布请求，成功3s后回到首页
function release(data) {
  ajax({ url: '/posts', method: 'post', data }, function (res) {
    if (res.code === 200) {
      showTip('发布成功！')
      setTimeout(function () {
        $(location).attr('href', 'index.html')
      }, 3000)
    }
  })
}