// 发布信息选则分类数据 子分类中的id替代classifyId
var relClassifyData = [
  { id: '1', value: '本地发现' },
  {
    id: '2',
    value: '本地供需',
    childs: [
      { id: '4', value: '本地需求' },
      { id: '5', value: '本地供应' }
    ]
  },
  {
    id: '3',
    value: '本地展厅',
    childs: [
      { id: "6", value: '衣' },
      { id: "7", value: '食' },
      { id: "8", value: '住' },
      { id: "9", value: '行' },
      { id: "10", value: '健康美容' },
      { id: "11", value: '家政教育' },
      { id: "12", value: '工作休闲' },
    ]
  }
]

var birthData = [
  { id: '1', value: '本地发现' },
  {
    id: '2',
    value: '本地供需',
    childs: [
      { id: '4', value: '本地需求' },
      { id: '5', value: '本地供应' }
    ]
  },
  {
    id: '3',
    value: '本地展厅',
    childs: [
      { id: "6", value: '衣' },
      { id: "7", value: '食' },
      { id: "8", value: '住' },
      { id: "9", value: '行' },
      { id: "10", value: '健康美容' },
      { id: "11", value: '家政教育' },
      { id: "12", value: '工作休闲' },
    ]
  }
]