// 获取用户信息
getUserInfo()

// 获取用户信息
function getUserInfo() {
  let [userInfo, goodNum] = ['', '']
  ajax({ url: '/account/my' }, function (res) {
    let { result } = res
    console.log(res);
    userInfo = `
    <a class="user-info-tx" href="./user-home.html?userId=${result.id}"><img src="${result.headImageUrl}" alt=""></a>
    <div class="info-box">
      <p class="nick">
        <span class="nick-name">${result.nickname}</span>
        <img src="./images/${result.sex == '男' ? 'man.png' : 'woman.png'}" class="sex"></img>
        <span>${result.census} ${result.sex} ${result.maritalStatus}</span>
      </p>
      <p>单位名称：${result.shopName}</p>
      <p>主营：${result.primaryService}</p>
    </div>
    <a class="update" href="./user-info-setting.html">修改资料</a>`
    $('.user-info').html(userInfo)
    goodNum = `
    <a href="./attention-list.html">${result.followCount}<span>关注</span></a>
    <a href="./good-list.html">${result.supportCount}<span>点赞</span></a>
    <a href="./fans-list.html">${result.fansCount}<span>粉丝</span></a>
    <a href="#">${result.popularityCount}<span>人气</span></a>`
    $('.good-num').html(goodNum)
    $('.news-num').text(result.unreadMessageCount)
    $('.phone-num').text(result.phoneNumber)
  })
}

// 以下是跳转方法
$('.my-release').on('tap', function () {
  $(location).attr('href', './my-repease.html')
})
$('.my-news').on('tap', function () {
  $(location).attr('href', './my-news.html')
})
$('.my-phone').on('tap', function () {
  $(location).attr('href', './update-phone-num.html')
})
$('.rank').on('tap', function () {
  $(location).attr('href', './rank.html')
})