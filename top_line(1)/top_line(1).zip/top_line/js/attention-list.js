let [page, pageSize] = [1, 10]

getFollowList()

function getFollowList() {
  let followListHTML = ''
  ajax({ url: '/follow', data: { page, pageSize } }, function (res) {
    let { result } = res
    if (result.length === 0) {
      scroll.finishPullUp()
      showTip('没有更多了')
    }
    result.forEach(item => {
      followListHTML += `
      <div class="good-box">
        <a class="good-user-tx" href="./user-home.html?userId=${item.id}">
          <img src="${item.headImageUrl}" alt="">
        </a>
        <div class="good-user-info">
          <p class="good-title">
            <span class="nick-name">${item.nickname}</span>
            <img src="./images/${item.sex === '男' ? 'man.png' : 'woman.png'}" class="sex-icon"></img>
            <span class="age">${item.age}岁</span>
          </p>
          <span class="good-dw">
            <i class="dw-icon"></i>
            <span>${item.address}</span>
          </span>
        </div>
        <div class="attention">
          <a user-id="${item.id}" href="javascript:;">${item.follow ? '取消关注' : '关注'}</a>
          <span class="user-length">${item.distance}</span>
        </div>
      </div>`
    })
    $('#content').append(followListHTML)
    // 通过下拉刷新、上拉加载更多时触发
    $('.pull-down-wrap').hide(500)
    $('.pull-up-wrap').hide(500)
    // 重新计算 better-scroll，当 DOM 结构发生变化的时候务必要调用确保滚动的效果正常。
    scroll.refresh()
    // 当上拉或下拉刷新数据加载完毕后，需要调用以下方法告诉 better-scroll 数据已加载。
    scroll.finishPullDown()
    scroll.finishPullUp()
  })
}

// 点击关注
$('#content').on('tap', '.attention a', function () {
  let _this = $(this)
  ajax({ url: '/follow', method: 'post', data: { userId: $(this).attr('user-id') } }, function (res) {
    if (res.result.status === 1) {
      showTip('取消成功!')
      _this.parents('.good-box').remove()
    }
  })
})

/* 上下拉刷新 better-scroll插件 */
let scroll = new BScroll($('body').get(0), {
  pullDownRefresh: {
    threshold: 100,
    stop: 50
  },
  pullUpLoad: {
    threshold: 100,
  }
})
// 下拉刷新
scroll.on('pullingDown', function () {
  $('.pull-down-wrap').show()
  // 确保获取最新帖子
  page = 1
  getFollowList()
})
// 上拉拉加载更多
scroll.on('pullingUp', function () {
  $('.pull-up-wrap').show()
  page++
  getFollowList()
})