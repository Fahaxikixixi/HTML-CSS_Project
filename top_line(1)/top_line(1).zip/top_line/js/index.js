// 获取帖子参数
let page = 1
let pageSize = 5

// 登陆
login()
// 自动生成banner图
getBanner()
// 自动生成banner下边的头条广告轮播
getAdvert()
// 获取帖子列表
getInvitation()

// 获取code 在登陆时调用
function getCode() {
	const code = location.href.split('?')[1]
	if (!code) return {}
	const obj = {}
	code.split('&').forEach(item => {
		const arr = item.split('=')
		obj[arr[0]] = arr[1]
	})
	return obj
}

// 登陆 获取token
function login() {
	const {
		code
	} = getCode()
	let localToken = localStorage.getItem('token') || ''
	// 如果本地token存在则不发起请求
	if (localToken) return;
	// 获取token
	$.ajax({
		url: 'http://118.24.155.202/oauth/wechat',
		data: {
			code
		},
		method: 'POST',
		type: 'application/json',
		success: function(res) {
			let token = res.result.accessToken || ''
			if (!token) {
				$(location).attr('href', 'login.html')
			}
			localStorage.setItem('token', token)
		},
		error: function(err) {
			$(location).attr('href', 'login.html')
		}
	})
}

// 请求banner轮播图
function getBanner() {
	ajax({
		url: '/advert/discover'
	}, function(res) {
		let {
			result
		} = res
		let bannerHTML = ''

		result.forEach(item => {
			bannerHTML +=
				`<div class="swiper-slide">
          <a href="${item.filePath}"><img src="${item.filePath}" width="100%" alt=""></a>
        </div>`
		})

		$('#banner-swiper .swiper-wrapper').html(bannerHTML)
		let bannerSwiper = new Swiper('#banner-swiper', {
			loop: true,
			autoplay: {
				disableOnInteraction: false,
				delay: 3000,
			}
		})
	})
}

// 请求banner下小广告轮播数据
function getAdvert() {
	ajax({
		url: '/posts/discover/headlinesSlider'
	}, function(res) {
		let {
			result
		} = res
		let advertHTML = ''

		result.forEach(item => {
			advertHTML +=
				`<div class="swiper-slide">
          <a class="advert-item">
            <img src="${item.headImageUrl}" class="tx"></img>
            <span class="hot_text">${item.summary}</span>
          </a>
        </div>`
		})
		$('#advert-swiper .swiper-wrapper').html(advertHTML)
		let advertSwiper = new Swiper('#advert-swiper', {
			direction: 'vertical',
			loop: true,
			autoplay: {
				disableOnInteraction: false,
				delay: 3000,
			}
		})
	})
}

// 获取帖子列表数据
function getInvitation() {
	ajax({
		url: '/posts/discover',
		data: {
			page,
			pageSize
		}
	}, function(res) {
		let {
			result
		} = res
		let invitationHTML = ''
		if (result.length === 0) {
			scroll.finishPullUp()
			showTip('没有更多了')
		}
		result.forEach(item => {
			// 帖子图片结构
			let imgList = ''
			// 点赞头像结构
			let goodList = ''

			// 帖子图片结构渲染
			for (let i = 0; i < item.albums.length; i++) {
				// 视频
				if (item.albums[i].type == "video") {
					imgList +=
						`
          <video poster="${item.albums[i].coverUrl}" src="${item.albums[i].url}" controls></video>
          `
				}
				// 图片
				if (item.albums[i].type == "image") {
					imgList +=
						`
          <img src="${item.albums[i].url}" alt="" data-preview-src="" data-preview-group="${item.id}">
          `
				}
			}
			// 点赞头像结构渲染
			for (let i = 0; i < item.supportUser.length; i++) {
				// 控制最长不超过8个头像，超过的不显示
				if (i > 7) break;
				goodList +=
					`
        <li>
          <a href="./user-home.html?userId=${item.user.id}">
            <img src="${item.supportUser[i].headImageUrl}" width="100%" alt="">
          </a>
        </li>`
			}
			// 帖子列表数据渲染,项帖子都保存发帖用户的id(user-id)和当前帖子id(post-id)
			invitationHTML +=
				`<li post-id="${item.id}" uesr-id="${item.user.id}">
          <div class="cont-header">
            <div class="cont-header-wrap">
              <a href="./user-home.html?userId=${item.user.id}"><img class="user_tx" src="${item.user.headImageUrl}" alt=""></a>
              <div>
                <p class="user_name">${item.user.nickname}</p>
                <div class="age">
                  <span class="user_age">${item.user.age}岁</span>
                  <img src="./images/${item.user.sex == '男' ? 'man.png' : 'woman.png'}" class="sex_icon"></img>
                </div>
              </div>
            </div>
            <div>
              <div class="attention-box clear">
                <div class="handle fr">‧‧‧</div>
                <div class="attention">
                  <a class="follow" href="javascript:;">${item.user.follow ? '取消关注' : '关注'}</a><a href="tel:${item.user.phoneNumber}">电话</a>
                </div>
              </div>
              <div class="handle_wrap">
                <p class="time_info">
                  <span>${item.createDay}</span>
                  <span>${item.createHour}</span>
                  <span>${item.distance}</span>
                </p>
              </div>
            </div>
          </div>
          <div class="cont-box">
            <p class="content-text">
              ${item.content}
            </p>
            <div class="img-box" style="display:${item.albums.length > 0 ? 'flex' : 'none'}">
            ${imgList}
            </div>
            <p class="site" style="display:${item.showAddress ? 'block' : 'none'}">${item.address}</p>
            <div class="interflow">
              <div class="good-box">
                <a class="clickgood">
                  <img src="./images/${item.isSupported ? 'good_active.png' : 'good.png'}"><span>${item.supportCount}</span>
                </a>
                <a class="views">
                  <img src="./images/views.png">
                  <span>${item.viewCount}</span>
                </a>
              </div>
              <div class="views-peoples">
                <ul class="good-list">
                  ${goodList}
                  <li style="display:${item.supportUser.length == 0 ? 'none' : 'block'}">
                    <a href="./good-list.html"></a>
                  </li>
                </ul>
              </div>
              <div class="toshare">
                <a href="./share.html" class="share"></a>
                <a class="to-top" style="display: ${item.canHeadlines ? 'inline' : 'none'}"></a>
              </div>
            </div>
          </div>
        </li>`
		})
		// page===1时,说明是第一次进入页面或者下拉刷新页面，其它都是上拉加载更多
		if (page === 1) {
			$('.content').html(invitationHTML)
		} else {
			$('.content').append(invitationHTML)
		}
		// 图片缩放
		imgZoom()
		// 通过下拉刷新、上拉加载更多时触发
		$('.pull-down-wrap').hide(500)
		$('.pull-up-wrap').hide(500)
		// 重新计算 better-scroll，当 DOM 结构发生变化的时候务必要调用确保滚动的效果正常。
		scroll.refresh()
		// 当上拉或下拉刷新数据加载完毕后，需要调用以下方法告诉 better-scroll 数据已加载。
		scroll.finishPullDown()
		scroll.finishPullUp()
	})
}

// 点击显示关注框
$('.content').on('tap', '.handle', function(e) {
	$('.attention').fadeOut(500)
	$(this).next().fadeIn(500)
	// 阻止冒泡，避免触发body上的的隐藏关注框事件
	e.stopPropagation()
})

// 点击任意地方隐藏关注盒子
$('body').on('tap', function() {
	$('.attention').fadeOut(500)
})

// 点击关注 保存所有的帖子列表，当点击一个帖子的关注时，该发帖用户所有的帖子都应该变为取消关注
$('.content').on('tap', '.follow', function() {
	let allLi = $('.content>li')
	let userId = $(this).parents('li').eq(0).attr('uesr-id')

	ajax({
		url: '/follow',
		method: 'post',
		data: {
			userId
		}
	}, function(res) {
		if (res.code === 400) showTip(res.message);
		if (res.result.status === 0) {
			allLi.each(function() {
				if ($(this).attr('uesr-id') == userId) {
					$(this).find('.follow').eq(0).text('取消关注')
					showTip('关注成功')
				}
			})
		}
		if (res.result.status === 1) {
			allLi.each(function() {
				if ($(this).attr('uesr-id') == userId) {
					$(this).find('.follow').eq(0).text('关注')
					showTip('取消成功')
				}
			})
		}
	})
})

// 点赞
$('.content').on('tap', '.clickgood', function() {
	let postId = $(this).parents('li').eq(0).attr('post-id')
	let _this = $(this)
	ajax({
		url: '/posts/support',
		method: 'post',
		data: {
			postId
		}
	}, function(res) {
		if (res.result.status === 0) {
			let num = Number(_this.children('span').text())
			_this.children('img').attr('src', './images/good_active.png')
			_this.children('span').text(num + 1)
		}
		if (res.result.status === 1) {
			let num = Number(_this.children('span').text())
			_this.children('img').attr('src', './images/good.png')
			_this.children('span').text(num - 1)
		}
	})
})

// 图片缩放 fly-zomm-img插件
function imgZoom() {
	$('.img-box').FlyZommImg({
		rollSpeed: 200, //切换速度
		miscellaneous: false, //是否显示底部辅助按钮
		closeBtn: true, //是否打开右上角关闭按钮
		hideClass: 'hideImg', //不需要显示预览的 class
		imgQuality: 'thumb', // ',//图片质量类型  thumb 缩略图  original 默认原图
		slitherCallback: function(direction, DOM) { //左滑动回调 两个参数 第一个动向 'left,firstClick,close' 第二个 当前操作DOM
			setTimeout(function() {
				// 为了一开始居中显示
				$('.fly-zoom-box-img').css('width', '100%').css('height', 'auto').css('top', 0).css('bottom', 0).css('margin',
					'auto');
			}, 300)
		}
	})
}

/* 上下拉刷新 better-scroll插件 */
let scroll = new BScroll($('body').get(0), {
	pullDownRefresh: {
		threshold: 100,
		stop: 50
	},
	pullUpLoad: {
		threshold: 100,
	}
})
// 下拉刷新
scroll.on('pullingDown', function() {
	$('.pull-down-wrap').show()
	// 确保获取最新帖子
	page = 1
	getInvitation()
})
// 上拉拉加载更多
scroll.on('pullingUp', function() {
	$('.pull-up-wrap').show()
	page++
	getInvitation()
})
