/* rem适配 */
(function () {
  let html = document.documentElement;
  let hw = html.getBoundingClientRect().width;
  // console.log(hw);
  /* 
  设计稿width=375px
  25rem=375px
  1rem=15px
  */
  if (hw <= 750) {
    html.style.fontSize = hw / 25 + 'px';
  }
})()

// 添加tap事件
$(document).on("touchstart", function (evt) {
  var $target = $(evt.target);
  if (!$target.hasClass("disable")) $target.data("isMoved", 0);
});

$(document).on("touchmove", function (evt) {
  var $target = $(evt.target);
  if (!$target.hasClass("disable")) $target.data("isMoved", 1);
});

$(document).on("touchend", function (evt) {
  var $target = $(evt.target);
  if (!$target.hasClass("disable") && $target.data("isMoved") == 0) $target.trigger("tap");
});

// 恢复a链接跳转
$(document).on('tap', 'a', function () {
  if ($(this).attr('href') && $(this).attr('href') != 'javascript:;') {
    $(location).attr('href', $(this).attr('href'))
  }
})

// let baseURL = '../JSON/'
// function ajax(obj, callback) {
//   $.ajax({
//     type: obj.method,
//     url: baseURL + obj.url,
//     data: obj.data,
//     success: (data) => {
//       callback(data);
//     },
//     error: function (err) {
//       console.log(err);
//     }
//   })
// }