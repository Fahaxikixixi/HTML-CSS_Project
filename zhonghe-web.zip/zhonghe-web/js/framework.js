/* 移动端事件 */
// 点击显示隐藏导航栏
$('.show-btn').on('click', function () {
  $('.btn').toggle(300)
  $('.btn2').toggle(300)
  $('#nav-list').toggle()
})

var myChart = echarts.init(document.getElementById('china-map'));

var provinces = ['shanghai', 'hebei', 'shanxi', 'neimenggu', 'liaoning', 'jilin', 'heilongjiang', 'jiangsu', 'zhejiang', 'anhui', 'fujian', 'jiangxi', 'shandong', 'henan', 'hubei', 'hunan', 'guangdong', 'guangxi', 'hainan', 'sichuan', 'guizhou', 'yunnan', 'xizang', 'shanxi1', 'gansu', 'qinghai', 'ningxia', 'xinjiang', 'beijing', 'tianjin', 'chongqing', 'xianggang', 'aomen'];

var provincesText = ['上海', '河北', '山西', '内蒙古', '辽宁', '吉林', '黑龙江', '江苏', '浙江', '安徽', '福建', '江西', '山东', '河南', '湖北', '湖南', '广东', '广西', '海南', '四川', '贵州', '云南', '西藏', '陕西', '甘肃', '青海', '宁夏', '新疆', '北京', '天津', '重庆', '香港', '澳门'];

let colorIni = [
  { name: '华东部', color: 'red' },
  { name: '华南部', color: 'blue' },
  { name: '江西部', color: 'pink' },
  { name: '北方部', color: 'yellow' },
  { name: '中国', color: '#4ea397' }
]
//根据地区显示相应文字的回调函数
function showHandle(areaName) {
  let res = ''
  if (areaName == '华东部') {
    res = '华东部：福建 、浙江、江苏、安徽、上海'
  } else if (areaName == '华南部') {
    res = '华南部：湖南、广西、贵州、广东、海南'
  } else if (areaName == '江西部') {
    res = '江西部：江西'
  } else if (areaName == '北方部') {
    res = '北方部：北京、天津、河北、山西、内蒙古、辽宁、吉林、黑龙江、山东、河南、湖北、广西、四川、贵州、云南、西藏、陕西、甘肃、宁夏、新疆、青海'
  }
  return res
}
//根据地区名获取颜色
function getAreaColor(areaName) {
  let result = '#4ea397'
  colorIni.forEach(value => {
    if (value.name === areaName)
      result = value.color
  })
  return result
}
//根据省名获取地区名
function findArea(pName) {
  let huadong = ['福建', '浙江', '江苏', '安徽', '上海']
  let huanan = ['湖南', '广西', '贵州', '广东', '海南']
  let jiangxi = '江西'
  if (huadong.includes(pName) == true) {
    return '华东部'
  }
  if (huanan.includes(pName) == true)
    return '华南部'
  if (pName == jiangxi)
    return '江西部'
  return '北方部'
}
//根据地区名获取地区数据
function getAreaData(areaName) {
  let huadong = [{ name: '福建', value: 0 }, { name: '浙江', value: 0 }, { name: '江苏', value: 0 }, { name: '安徽', value: 0 }, { name: '上海', value: 60 }]
  let huanan = [{ name: '湖南', value: 0 }, { name: '广西', value: 0 }, { name: '贵州', value: 0 }, { name: '广东', value: 0 }, { name: '海南', value: 0 }]
  let jiangxi = [{ name: '江西', value: 0 }]
  let data = []
  seriesData.forEach(value => {
    let obj = new Object()
    obj.name = value.name
    obj.value = value.value
    data.push(obj)
  })
  let areaArr = null
  if (areaName == '华东部') {
    areaArr = huadong
  } else if (areaName == '华南部') {
    areaArr = huanan
  } else if (areaName == '江西部') {
    areaArr = jiangxi
  } else if (areaName == '北方部') {
    return beifangArea
  } else {
    return seriesData
  }

  areaArr.forEach(value => {
    data.forEach((val, i) => {
      if (val.name == value.name) {
        data[i].selected = true
        data[i].value = value.value
      }
    })
  })
  return data
}
//配置
var seriesData = [{
  name: '北京',
  value: 10
}, {
  name: '天津',
  value: 0
}, {
  name: '上海',
  value: 60
}, {
  name: '重庆',
  value: 0
}, {
  name: '河北',
  value: 60
}, {
  name: '河南',
  value: 60
}, {
  name: '云南',
  value: 0
}, {
  name: '辽宁',
  value: 0
}, {
  name: '黑龙江',
  value: 0
}, {
  name: '湖南',
  value: 60
}, {
  name: '安徽',
  value: 0
}, {
  name: '山东',
  value: 60
}, {
  name: '新疆',
  value: 0
}, {
  name: '江苏',
  value: 0
}, {
  name: '浙江',
  value: 0
}, {
  name: '江西',
  value: 0
}, {
  name: '湖北',
  value: 60
}, {
  name: '广西',
  value: 60
}, {
  name: '甘肃',
  value: 0
}, {
  name: '山西',
  value: 60
}, {
  name: '内蒙古',
  value: 0
}, {
  name: '陕西',
  value: 0
}, {
  name: '吉林',
  value: 0
}, {
  name: '福建',
  value: 0
}, {
  name: '贵州',
  value: 0
}, {
  name: '广东',
  value: 597
}, {
  name: '青海',
  value: 0
}, {
  name: '西藏',
  value: 0
}, {
  name: '四川',
  value: 60
}, {
  name: '宁夏',
  value: 0
}, {
  name: '海南',
  value: 60
}, {
  name: '台湾',
  value: 0
}, {
  name: '香港',
  value: 0
}, {
  name: '澳门',
  value: 0
}]
var beifangArea = [{
  name: '北京',
  selected: true,
  value: 10
}, {
  name: '天津',
  selected: true,
  value: 0
}, {
  name: '重庆',
  selected: true,
  value: 0
}, {
  name: '河北',
  selected: true,
  value: 60
}, {
  name: '河南',
  selected: true,
  value: 60
}, {
  name: '云南',
  selected: true,
  value: 0
}, {
  name: '辽宁',
  selected: true,
  value: 0
}, {
  name: '黑龙江',
  selected: true,
  value: 0
}, {
  name: '湖南',
  value: 60
}, {
  name: '安徽',
  value: 0
}, {
  name: '山东',
  selected: true,
  value: 60
}, {
  name: '新疆',
  selected: true,
  value: 0
}, {
  name: '江苏',
  value: 0
}, {
  name: '浙江',
  value: 0
}, {
  name: '江西',
  value: 0
}, {
  name: '湖北',
  selected: true,
  value: 60
}, {
  name: '广西',
  value: 60
}, {
  name: '甘肃',
  selected: true,
  value: 0
}, {
  name: '山西',
  selected: true,
  value: 60
}, {
  name: '内蒙古',
  selected: true,
  value: 0
}, {
  name: '陕西',
  selected: true,
  value: 0
}, {
  name: '吉林',
  selected: true,
  value: 0
}, {
  name: '福建',
  value: 0
}, {
  name: '贵州',
  value: 0
}, {
  name: '广东',
  value: 597
}, {
  name: '青海',
  selected: true,
  value: 0
}, {
  name: '西藏',
  selected: true,
  value: 0
}, {
  name: '四川',
  selected: true,
  value: 60
}, {
  name: '宁夏',
  selected: true,
  value: 0
}, {
  name: '海南',
  value: 60
}, {
  name: '台湾',
  value: 0
}, {
  name: '香港',
  value: 0
}, {
  name: '澳门',
  value: 0
}];

function getOption(pName = null) {
  let areaName = '中国'
  let areaColor = '#4ea397'
  let areaData = seriesData
  if (pName !== null && pName !== '台湾' && pName !== '香港' && pName !== '澳门') {
    areaName = findArea(pName)
    areaData = getAreaData(areaName)
    areaColor = getAreaColor(areaName)
  }
  return option = {
    title: {
      text: areaName,
      left: 'center'
    },
    tooltip: {
      trigger: 'item',
      formatter: showHandle(areaName)
    },
    series: [
      {
        name: 'china',
        type: 'map',
        map: 'china',
        roam: false,//是否开启鼠标缩放和平移漫游
        top: "3%",//组件距离容器的距离

        zoom: 1.1,
        selectedMode: 'multi',
        label: {
          normal: {
            show: true,//显示省份标签
            textStyle: { color: "#fbfdfe" }//省份标签字体颜色
          },
          emphasis: {//对应的鼠标悬浮效果
            show: true,
            textStyle: { color: "#323232" }
          }
        },
        itemStyle: {
          normal: {
            borderWidth: .5,//区域边框宽度
            borderColor: '#0550c3',//区域边框颜色
            areaColor: "#4ea397",//区域文字颜色
          },
          emphasis: {
            borderWidth: .5,
            borderColor: '#4b0082',
            areaColor: areaColor,  //选中区域背景颜色
          }
        },
        data: areaData
      }
    ]
  }
}


// oBack.onclick = function () {
//   initEcharts("china", "中国");
// };

initEcharts("china", "中国");


function initEcharts(pName, Chinese_) {
  var tmpSeriesData = pName === "china" ? seriesData : [];

  myChart.setOption(getOption());
  // myChart.on('click',function (params) {
  //     myChart.setOption(getOption(params.name))
  // })
  myChart.on('mouseover', function (params) {
    myChart.setOption(getOption(params.name))
  })
}