// 点击显示招聘详情
$('.show').on("click", function () {
  let _this = $(this)
  $(this).parents('.list-box').children('.info-box').toggle(function () {
    _this.text(_this.text() == '展开' ? '隐藏':"展开")
  })
})

// 跑马灯轮播效果
$(function () {
  var timer;
  var number = 0;

  var cont = document.getElementsByClassName('marquee-list')[0];
  cont.innerHTML += cont.innerHTML;

  function AutoPlay() {
    clearTimeout(timer);
    timer = setInterval(function () {
      number--;
      if (number == -900) {
        number = 0;
      }
      $('.marquee-list').css('left', number);
    }, 10);
  }
  AutoPlay();

  // 鼠标滑入暂停
  $('.marquee-list li').mouseenter(function () {
    clearTimeout(timer);
  }).mouseleave(function () {
    AutoPlay();
  })
})

/* 移动端事件 */
// 点击显示隐藏导航栏
$('.show-btn').on('click', function () {
  $('.btn').toggle(300)
  $('.btn2').toggle(300)
  $('#nav-list').toggle()
})