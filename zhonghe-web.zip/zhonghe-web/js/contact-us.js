/* 移动端事件 */
// 点击显示隐藏导航栏
$('.show-btn').on('click', function () {
  $('.btn').toggle(300)
  $('.btn2').toggle(300)
  $('#nav-list').toggle()
})

// 百度地图API功能
var map = new BMap.Map('allmap');
var poi = new BMap.Point(115.885776, 28.659169);
map.centerAndZoom(poi, 17);
map.enableScrollWheelZoom();
var content = '<div style="margin:0;line-height:2em;padding:2px;">' +
  '地址：江西南昌市西湖区洪池路2号汇景国际大厦B座7-8楼<br/>邮政编码：330000 <br/>电话：0791-86589788<br/>公司传真：0791-83499979<br/>' +
  '</div>';
//创建检索信息窗口对象
var searchInfoWindow = null;
searchInfoWindow = new BMapLib.SearchInfoWindow(map, content, {
  title: "江西众和化工有限公司", //标题
  width: 320, //宽度
  height: 110,
  isOpen: 1, //高度
  panel: "panel", //检索结果面板
  enableAutoPan: true, //自动平移
  searchTypes: [
    BMAPLIB_TAB_SEARCH, //周边检索
    BMAPLIB_TAB_TO_HERE, //到这里去
    BMAPLIB_TAB_FROM_HERE //从这里出发
  ]
});
var marker = new BMap.Marker(poi); //创建marker对象
marker.enableDragging(); //marker可拖拽
marker.addEventListener("click", function (e) {
  searchInfoWindow.open(marker);
})
map.addOverlay(marker); //在地图中添加marker
//样式1
var searchInfoWindow1 = new BMapLib.SearchInfoWindow(map, "信息框1内容", {
  title: "信息框1", //标题
  panel: "panel", //检索结果面板
  enableAutoPan: true, //自动平移
  searchTypes: [
    BMAPLIB_TAB_FROM_HERE, //从这里出发
    BMAPLIB_TAB_SEARCH //周边检索
  ]
});

function openInfoWindow1() {
  searchInfoWindow1.open(new BMap.Point(115.885776, 28.659169));
}
//样式2
var searchInfoWindow2 = new BMapLib.SearchInfoWindow(map, "信息框2内容", {
  title: "信息框2", //标题
  panel: "panel", //检索结果面板
  enableAutoPan: true, //自动平移
  searchTypes: [
    BMAPLIB_TAB_SEARCH //周边检索
  ]
});

function openInfoWindow2() {
  searchInfoWindow2.open(new BMap.Point(115.885776, 28.659169));
}
//样式3
var searchInfoWindow3 = new BMapLib.SearchInfoWindow(map, "信息框3内容", {
  title: "信息框3", //标题
  width: 290, //宽度
  height: 40, //高度
  panel: "panel", //检索结果面板
  enableAutoPan: true, //自动平移
  searchTypes: []
});

function openInfoWindow3() {
  searchInfoWindow3.open(new BMap.Point(115.885776, 28.659169));
}
map.setMapStyle(setMapStyle);
var myStyleJson = [{
  "featureType": "land",
  "elementType": "geometry",
  "stylers": {
    "color": "#212121"
  }
},
{
  "featureType": "building",
  "elementType": "geometry",
  "stylers": {
    "color": "#2b2b2b"
  }
},
{
  "featureType": "highway",
  "elementType": "all",
  "stylers": {
    "lightness": -42,
    "saturation": -91
  }
},
{
  "featureType": "arterial",
  "elementType": "geometry",
  "stylers": {
    "lightness": -77,
    "saturation": -94
  }
},
{
  "featureType": "green",
  "elementType": "geometry",
  "stylers": {
    "color": "#1b1b1b"
  }
},
{
  "featureType": "water",
  "elementType": "geometry",
  "stylers": {
    "color": "#181818"
  }
},
{
  "featureType": "subway",
  "elementType": "geometry.stroke",
  "stylers": {
    "color": "#181818"
  }
},
{
  "featureType": "railway",
  "elementType": "geometry",
  "stylers": {
    "lightness": -52
  }
},
{
  "featureType": "all",
  "elementType": "labels.text.stroke",
  "stylers": {
    "color": "#313131"
  }
},
{
  "featureType": "all",
  "elementType": "labels.text.fill",
  "stylers": {
    "color": "#8b8787"
  }
},
{
  "featureType": "manmade",
  "elementType": "geometry",
  "stylers": {
    "color": "#1b1b1b"
  }
},
{
  "featureType": "local",
  "elementType": "geometry",
  "stylers": {
    "lightness": -75,
    "saturation": -91
  }
},
{
  "featureType": "subway",
  "elementType": "geometry",
  "stylers": {
    "lightness": -65
  }
},
{
  "featureType": "background",
  "elementType": "all",
  "stylers": {
    "lightness": -40
  }
},
{
  "featureType": "boundary",
  "elementType": "geometry",
  "stylers": {
    "color": "#8b8787",
    "weight": "1",
    "lightness": -29
  }
},
{
  "featureType": "land",
  "elementType": "labels.text.fill",
  "stylers": {}
}
];
map.setMapStyle({
  styleJson: myStyleJson
});