// banner轮播swiper插件
var mySwiper = new Swiper('#news-swiper', {
  loop: true, // 循环模式选项
  autoplay: {
    disableOnInteraction: false,
    delay: 3000,
  },
  pagination: {
    el: '.swiper-pagination',
  },
  // 如果需要前进后退按钮
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  }
})

/* 移动端事件 */
// 点击显示隐藏导航栏
$('.show-btn').on('click', function () {
  $('.btn').toggle(300)
  $('.btn2').toggle(300)
  $('#nav-list').toggle()
})