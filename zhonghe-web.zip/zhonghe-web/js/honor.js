/* 移动端事件 */
// 点击显示隐藏导航栏
$('.show-btn').on('click', function () {
  $('.btn').toggle(300)
  $('.btn2').toggle(300)
  $('#nav-list').toggle()
})