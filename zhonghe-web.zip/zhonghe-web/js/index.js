changeBannerHeight()
// 动态计算banner的高度
function changeBannerHeight() {
  let clientW = document.documentElement.clientWidth
  // 获取视口高度
  let clientH = document.documentElement.clientHeight
  // 获取头部高度
  let headerH = document.getElementById('header').clientHeight
  // 计算banner高度
  let bannerHeight = clientH - headerH
  if (clientW > 1025) {
    $('.banner').css('height', bannerHeight)
  }
}
// 窗口发生改变时动态计算banner的高度
window.onresize = function () {
  changeBannerHeight()
}
// banner轮播swiper插件
var mySwiper = new Swiper('.banner', {
  // direction: 'vertical', // 垂直切换选项
  loop: true, // 循环模式选项
  autoplay: {
    disableOnInteraction: false,
    delay: 3000,
  },
  // 如果需要前进后退按钮
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  }
})

/* 移动端事件 */
// 点击显示隐藏导航栏
$('.show-btn').on('click', function () {
  $('.btn').toggle(300)
  $('.btn2').toggle(300)
  $('#nav-list').toggle()
})