// 鼠标移入招聘岗位
$('.quarters').on('mouseover',function(){
  $(this).addClass('active')
  $('.process').removeClass('active')
  $('.tab1').show()
  $('.tab2').hide()
})
// 鼠标移入招聘流程
$('.process').on('mouseover',function(){
  $(this).addClass('active')
  $('.quarters').removeClass('active')
  $('.tab1').hide()
  $('.tab2').show()
})
// 鼠标移入招聘岗位
$('.quarters').on('click',function(){
  $(this).addClass('active')
  $('.process').removeClass('active')
  $('.tab1').show()
  $('.tab2').hide()
})
// 鼠标移入招聘流程
$('.process').on('click',function(){
  $(this).addClass('active')
  $('.quarters').removeClass('active')
  $('.tab1').hide()
  $('.tab2').show()
})

// 跑马灯轮播效果
$(function () {
  var timer;
  var number = 0;

  var cont = document.getElementsByClassName('marquee-list')[0];
  cont.innerHTML += cont.innerHTML;

  function AutoPlay() {
    clearTimeout(timer);
    timer = setInterval(function () {
      number--;
      if (number == -900) {
        number = 0;
      }
      $('.marquee-list').css('left', number);
    }, 10);
  }
  AutoPlay();

  // 鼠标滑入暂停
  $('.marquee-list li').mouseenter(function () {
    clearTimeout(timer);
  }).mouseleave(function () {
    AutoPlay();
  })
})

/* 移动端事件 */
// 点击显示隐藏导航栏
$('.show-btn').on('click', function () {
  $('.btn').toggle(300)
  $('.btn2').toggle(300)
  $('#nav-list').toggle()
})
